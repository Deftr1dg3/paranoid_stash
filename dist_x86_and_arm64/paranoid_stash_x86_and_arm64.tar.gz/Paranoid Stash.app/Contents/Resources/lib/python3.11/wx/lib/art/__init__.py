"""
Currently provides some flag icons based on:
http://www.famfamfam.com/lab/icons/flags
"""
