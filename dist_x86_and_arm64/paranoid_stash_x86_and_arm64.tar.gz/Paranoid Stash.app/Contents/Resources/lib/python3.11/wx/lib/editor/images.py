
# images converted with wxPython's img2py.py tool

# 12/14/2003 - Jeff Grimmett (grimmtooth@softhome.net)
#
# o 2.5 compatibility update.
#

from wx.lib.embeddedimage import PyEmbeddedImage

EofImage = PyEmbeddedImage(
    "iVBORw0KGgoAAAANSUhEUgAAAAcAAAAHCAYAAADEUlfTAAAABHNCSVQICAgIfAhkiAAAADpJ"
    "REFUeJxdjsENADAIAsUJbv8p3aB90WD5KJwJCihrZg4g+06Q88EM0quqFkh1dqQAtZcfrIcc"
    "5OEFYDIVnsU0yrQAAAAASUVORK5CYII=")

